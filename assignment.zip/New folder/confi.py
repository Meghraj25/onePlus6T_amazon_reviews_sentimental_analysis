import mysql.connector

def dbConnect():
    
    mydb = mysql.connector.connect(host="localhost",user="root",passwd="",database="pydatabase")
    
    return mydb

