
# coding: utf-8

# In[1]:


import mysql.connector
import requests
from bs4 import BeautifulSoup
from datetime import datetime
import os
import confi
import mysql.connector
import zlib, base64


# In[2]:


import random
import time
import pickle


# In[3]:


connect = confi.dbConnect()
mycursor = connect.cursor()


# In[4]:


# ALL INPUT URLS FROM DATABASE
mycursor.execute("SELECT * FROM us_bestbuy_input WHERE status = 1")
inputs = mycursor.fetchall()


# In[5]:


date_time = datetime.now().strftime("%m_%d_%Y") #Todays date with 'm_d_y' format

detailspath = "corpus/us/bestBuy/details/" # PATH FOR STORING DETAILS P
path = "corpus/us/bestBuy/"+date_time

mycursor.execute("SELECT DISTINCT category_name FROM us_bestbuy_input WHERE status = 1")
categories = [list(i)[0] for i in mycursor.fetchall()]


if not os.path.isdir("corpus/us/bestBuy/"+date_time): #Checks If directory with todays date exists or not
    os.mkdir(path)
    for category in categories:
        os.mkdir(path+"/"+category)
        
for category in categories:
    if not os.path.isdir("corpus/us/bestBuy/details/"+category):
        os.mkdir("corpus/us/bestBuy/details/"+category)


# In[6]:


user_agent_list = ['Mozilla/5.0 (X11; U; UNICOS lcLinux; en-US) Gecko/20140730 (KHTML, like Gecko, Safari/419.3) Arora/0.8.0','Mozilla/5.0 (X11; U; Linux; de-DE) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0','Mozilla/5.0 (Windows; U; ; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0','Mozilla/5.0 (Windows; U; ; en-NZ) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0','Mozilla/5.0 (Windows; U; ; en-EN) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0']
proxies = {1: {'https': '178.128.75.148:3128'}}


# ### ADD '&intl=nosplash' AFTER EVERY URL TO AVOID CONTRY SELECTION PAGE

# In[7]:


def pageCrawler(link,category,catid,pg):
    
    # TO CATCH EXCEPTIONS
    try:
        sourceCode = requests.get(link+'&intl=nosplash',headers = {'User-Agent':random.choice(user_agent_list)},proxies=proxies)
    except:
        print('Sleeping for 5 seconds')
        time.sleep(5)
        pageCrawler(link,category,catid,pg)
        
    plaintext = sourceCode.text
    soup = BeautifulSoup(plaintext)
    
    # PAGE SAVING MECHANISM FOR CATEGORY PAGE
    text = plaintext+'<url>'+link+'</url>'
    code = base64. b64encode(zlib. compress(text. encode('utf-8'),9))
    code = code. decode('utf-8')

    text_file = open(path+'/'+category+'/MSFT_US_BestBuy_cat_'+catid+'_pg_'+str(pg)+'_'+category+".zlib", "w" ,encoding="utf-8")
    text_file.write(code)
    text_file.close()
    
    # FINDS PRODUCTS LIST ON PAGE AND SAVE ALL DETAIL PAGE URLS
    products = soup.find_all('li',{'class':'sku-item'})
    if products:
        for product in products:
            if product['data-sku-id'] not in SKUs:
                link = product.find('a',{'class':'image-link'})
                detailLinks.append([product['data-sku-id'],'https://www.bestbuy.com'+link['href'],category])
    
    # IF NEXT PAGE BUTTON FOUND:IT RECALLS SAME FUNCTION WITH NEXT BUTTON URL
    next_page = soup.find('a',{'class':'ficon-caret-right'})
    if next_page is not None:
        if(next_page['aria-disabled'] == 'false'):
            pg += 1
            pageCrawler(next_page['href'],category,catid,pg)
        
        else:
            print('End of category id '+catid)
             


# In[8]:


detailLinks = []
for inp in inputs:
    
    # LIST OF ALL SKU OF SPECIFIC CATEGORY
    filesList=os.listdir('corpus/us/bestBuy/details/'+inp[1]+'/') 
    SKUs=[(x.split('.')[0]).split('-')[-1] for x in filesList]
    
    pageCrawler(inp[5],inp[1],str(inp[0]),1)
    
# STORING DETAIL LINKS LIST FOR PARTICULAR DATE IN DATE FOLDER    
with open(path+'/'+date_time+'bestBuy_detailLinks.pkl', 'wb') as f:
    pickle.dump(detailLinks, f)


# In[11]:


def detailsCrawler(detailLink,sku,category):
    
        try:
            sourceCode = requests.get(detailLink+'&intl=nosplash',headers = {'User-Agent':random.choice(user_agent_list)},proxies=proxies)
        except:
            print('sleeping for 5 seconds')
            time.sleep(5)
            detailsCrawler(detailLink,sku,category)
            
            
        # PAGE SAVING MECHANISM FOR DETAILS PAGE WITH CATEGORY AND SKU    
        plaintext = sourceCode.text
        soup = BeautifulSoup(plaintext)
        
        text = plaintext+'<url>'+detailLink+'</url>'
        code = base64. b64encode(zlib. compress(text. encode('utf-8'),9))
        code = code. decode('utf-8')

        text_file = open(detailspath+category+'/'+'MSFT-US-BestBuy-Prod-'+sku+".zlib", "w" ,encoding="utf-8")
        text_file.write(code)
        text_file.close()


# In[12]:


# CALLING DETAILLINK CRAWLER FOR ALL DETAIL LINKS
for detailLink in detailLinks:
    
    detailsCrawler(detailLink[1],detailLink[0],detailLink[2]) 

