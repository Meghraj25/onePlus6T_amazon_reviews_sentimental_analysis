
# coding: utf-8

# In[46]:


import mysql.connector
import requests
from bs4 import BeautifulSoup
from datetime import datetime
import os
import confi
import mysql.connector
import zlib, base64


# In[47]:


import random
import time
import pickle
import json


# In[48]:


user_agent_list = ['Mozilla/5.0 (X11; U; UNICOS lcLinux; en-US) Gecko/20140730 (KHTML, like Gecko, Safari/419.3) Arora/0.8.0','Mozilla/5.0 (X11; U; Linux; de-DE) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0','Mozilla/5.0 (Windows; U; ; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0','Mozilla/5.0 (Windows; U; ; en-NZ) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0','Mozilla/5.0 (Windows; U; ; en-EN) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0']
proxies = {1: {'https': '178.128.75.148:3128'}}


# In[49]:


connect = confi.dbConnect()
mycursor = connect.cursor()
mycursor.execute("SELECT * FROM us_walmart_input WHERE status = 1")
inputs = mycursor.fetchall()


# In[50]:


date_time = datetime.now().strftime("%m_%d_%Y") #Todays date with 'm_d_y' format

detailspath = "corpus/us/walmart/details/" # PATH FOR STORING DETAILS P
path = "corpus/us/walmart/"+date_time

mycursor.execute("SELECT DISTINCT category_name FROM us_walmart_input WHERE status = 1")
categories = [list(i)[0] for i in mycursor.fetchall()]


if not os.path.isdir("corpus/us/walmart/"+date_time): #Checks If directory with todays date exists or not
    os.mkdir(path)
    for category in categories:
        os.mkdir(path+"/"+category)
        
for category in categories:
    if not os.path.isdir(detailspath+category):
        os.mkdir(detailspath+category)


# In[51]:


def pageCrawler(link,catid,page_type,category,pg):
    sourceCode = requests.get(link,headers = {'User-Agent':random.choice(user_agent_list)},proxies=proxies)
    plaintext = sourceCode.text
    soup = BeautifulSoup(plaintext)
    
    data = soup.find('script',{'id':'searchContent'}) # FINDS SCRIPT WITH ID = SEARCHCONTENT 
    data0 = soup.find('script',{'id':'category'}) # FINDS SCRIPT WITH ID = CATEGORY
    data1 = soup.find('div',{'class':'TwoPanel'}) # FINDS SLIDER BANNER
    data2 = soup.find('div',{'class':'POVModule-imageWrapper'}) # FINDS SLIDER BANNER
    
    # IF SCRIPT WITH ID SEARCHCONTENT PRESENT
    if data is not None:
        data_dict = json.loads(data.text)
        # IF NUMBER OF ITEMS IN THE SCRIPT IS ZERO THEN IT IS A BANNER PAGE
        if (len(data_dict['searchContent']['preso']['items']) != 0):
            products = data_dict['searchContent']['preso']['items']
            
            with open(path+'/'+category+'/MSFT_US_Walmart_cat_'+catid+'_pg_'+str(pg)+'_'+category+'.json', 'w') as jfile:
                json.dump(products, jfile)
                
            for product in products:
                if product['productId'] not in SKUs:
                    detailLinks.append([product['productId'],'https://www.walmart.com'+product['productPageUrl'],category])

            pagination = data_dict['searchContent']['preso']['pagination']
            if 'next' in pagination.keys():
                pg += 1
                return pageCrawler('https://www.walmart.com/browse/?'+pagination['next']['url'],catid,page_type,category,pg)
            
        elif data1 is not None:
            url = data1.find('a')['href']
            domain = ''
            if "www.walmart.com" not in url:
                domain = "https://www.walmart.com"
            return pageCrawler(domain+url,catid,page_type,category,pg)
            
        elif data2 is not None:
            url = data2.find('a')['href']
            domain = ''
            if "www.walmart.com" not in url:
                domain = "https://www.walmart.com"
            return pageCrawler(domain+url,catid,page_type,category,pg)
            
    # IF SCRIPT WITH ID CATEGORY PRESENT
    elif data0 is not None:
        data_dict = json.loads(data0.text)
        # IF NUMBER OF ITEMS IN THE SCRIPT IS ZERO THEN IT IS A BANNER PAGE
        if 'configs' in data_dict['category']['presoData']['modules']['center'][0].keys():
            print('Category ID is '+ str(catid))
            products = data_dict['category']['presoData']['modules']['center'][0]['configs']['items']
            with open(path+'/'+category+'/MSFT_US_Walmart_cat_'+catid+'_pg_'+str(pg)+'_'+category+'.json', 'w') as jfile:
                json.dump(products, jfile)
            for product in products:
                if product['productId'] not in SKUs:
                    detailLinks.append([product['productId'],'https://www.walmart.com'+product['productPageUrl'],category])

            pagination = data_dict['category']['presoData']['modules']['center'][0]['configs']['pagination']
            if 'next' in pagination.keys():
                pg += 1
                return pageCrawler('https://www.walmart.com/browse/?'+pagination['next']['url'],catid,page_type,category,pg)
                
        elif data1 is not None:
            url = data1.find('a')['href']
            domain = ''
            if "www.walmart.com" not in url:
                domain = "https://www.walmart.com"
            return pageCrawler(domain+url,catid,page_type,category,pg)
            
        elif data2 is not None:
            url = data2.find('a')['href']
            domain = ''
            if "www.walmart.com" not in url:
                domain = "https://www.walmart.com"
            return pageCrawler(domain+url,catid,page_type,category,pg)
        
    # IF NO SCRIPT BUT BANNER IS PRESENT        
    elif data1 is not None:
        url = data1.find('a')['href']
        domain = ''
        if "www.walmart.com" not in url:
            domain = "https://www.walmart.com"
        return pageCrawler(domain+url,catid,page_type,category,pg)

    elif data2 is not None:
        url = data2.find('a')['href']
        domain = ''
        if "www.walmart.com" not in url:
            domain = "https://www.walmart.com"
        return pageCrawler(domain+url,catid,page_type,category,pg)
        
        

        
    
        
    


# In[52]:


detailLinks = []
for inp in inputs:
    
    # LIST OF ALL SKU OF SPECIFIC CATEGORY
    filesList=os.listdir('corpus/us/walmart/details/'+inp[1]+'/') 
    SKUs=[(x.split('.')[0]).split('-')[-1] for x in filesList]
    pageCrawler(inp[5],str(inp[0]),inp[3],inp[1],1)


# In[55]:


def detailsCrawler(detailLink,sku,category):
    
        try:
            sourceCode = requests.get(detailLink,headers = {'User-Agent':random.choice(user_agent_list)},proxies=proxies)
        except:
            print('sleeping for 5 seconds')
            time.sleep(5)
            detailsCrawler(detailLink,sku,category)
            
            
        # PAGE SAVING MECHANISM FOR DETAILS PAGE WITH CATEGORY AND SKU    
        plaintext = sourceCode.text
        soup = BeautifulSoup(plaintext)
        
        text = plaintext+'<url>'+detailLink+'</url>'
        code = base64. b64encode(zlib. compress(text. encode('utf-8'),9))
        code = code. decode('utf-8')

        text_file = open(detailspath+category+'/'+'MSFT-US-Walmart-Prod-'+sku+".zlib", "w" ,encoding="utf-8")
        text_file.write(code)
        text_file.close()


# In[27]:


for detailLink in detailLinks:
    
    detailsCrawler(detailLink[1],detailLink[0],detailLink[2]) 


