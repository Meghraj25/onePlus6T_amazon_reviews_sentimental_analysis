
# coding: utf-8

# In[1]:


import mysql.connector
import requests
from bs4 import BeautifulSoup
from datetime import datetime
import os
import confi
import mysql.connector
import zlib, base64


# ### Check and creates directories to save text

# In[2]:


date_time = datetime.now().strftime("%m_%d_%Y") #Todays date with 'm_d_y' format
path = "corpus/us/dell/"+date_time
if not os.path.isdir("corpus/us/dell/"+date_time): #Checks If directory with todays date does not exist
    os.mkdir(path)
    os.mkdir(path+"/listing")
    os.mkdir(path+"/details")


# In[3]:


proxies = {
    1:{'http': '157.230.13.186:8080'},
    2:{'http': '104.248.220.143:3128'},
    3:{'http': '134.209.49.222:3128'},
    4:{'http': '206.81.5.28:3128'},
    5:{'http': '206.81.4.94:8080'},
    6:{'http': '68.110.172.76:3128'},
    7:{'http': '159.65.164.58:80'},
    8:{'http': '51.38.80.159:80'},
    9:{'http': '54.37.31.169:80'},
    10:{'http': '96.65.221.1:59161'}
}


# ### Database connection

# In[5]:


connect = confi.dbConnect()
mycursor = connect.cursor()


# ### Fetching Input data

# In[6]:


mycursor.execute("SELECT * FROM us_dell_input WHERE status = 1")
result = mycursor.fetchall()


# ### Page saving mechanism for category pages

# In[7]:


descs_urls = []
demo = []
for inp in result:
    
    sourceCode = requests.get(inp[5],headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'}, proxies=proxies)

    plaintext = sourceCode.text
    soup = BeautifulSoup(plaintext,'html.parser')

    h3tags = soup.find_all('h3',{'data-testid':'productseries'})
    atags = soup.find_all('a',{'data-testid':'productseries'})
    buttons = soup.find_all('a',{'class':'btn btn-success btn-block margin-top-10'})
    
    if h3tags is not None:
        for i in h3tags:
            descs_urls.append('http://www.dell.com'+i.parent['href'])
           


    if atags is not None:
        for i in atags:
            descs_urls.append('http://www.dell.com'+i['href'])
            demo.append(str(inp[0])+':http://www.dell.com'+i['href'])


    if buttons is not None:
        for i in buttons:
            descs_urls.append('https://deals.dell.com'+i['href'])
#             demo.append(str(inp[0])+':http://www.dell.com'+i['href'])

    plaintext = plaintext+'<url>'+inp[5]+'</url>'
    code = base64. b64encode(zlib. compress(plaintext. encode('utf-8'),9))
    code = code. decode('utf-8')

    text_file = open(path+"/listing/"+str(inp[0])+".zlib", "w" ,encoding="utf-8")
    text_file.write(code)
    text_file.close()


# ### Fetching all unique urls 

# In[8]:


print(len(descs_urls))
descs_urls = list(set(descs_urls))
print(len(descs_urls))


# ### Page saving mechanism for Details pages

# In[9]:


test_links = [] #to store links of varients of model
for link in descs_urls:
    
    x = link.split("/")[-1]
    
    if '-' not in link.split("/")[-1]: # Checks if skew present in the url or not
         
        sourceCode = requests.get(link,headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'}, proxies=proxies)
        plaintext = sourceCode.text
        
        
        plaintext = plaintext+'<url>'+link+'</url>'
        code = base64. b64encode(zlib. compress(plaintext. encode('utf-8'),9))
        code = code. decode('utf-8')
        
        text_file = open(path+"/details/"+x+".zlib", "w" ,encoding="utf-8")
        text_file.write(code)
        text_file.close()
        
    else:
        
        sourceCode = requests.get(link,headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'}, proxies=proxies)
        plaintext = sourceCode.text
        
        soup = BeautifulSoup(plaintext,'html.parser')
        
        for n in soup.find_all('span',{'data-testid':'configItemProduct'}):
            
            new_link = n.parent['href']
            test_links.append('http://www.dell.com'+new_link)
            
unique_prod_links = list(set(test_links))

for ulink in unique_prod_links:
    
    y = ulink.split("/")[-1]
    sourceCode = requests.get(ulink,headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'}, proxies=proxies)
    plaintext = sourceCode.text
    
    plaintext = plaintext+'<url>'+ulink+'</url>'
    code = base64. b64encode(zlib. compress(plaintext. encode('utf-8'),9))
    code = code. decode('utf-8')

    text_file = open(path+"/details/"+y+".txt", "w" ,encoding="utf-8")
    text_file.write(code)
    text_file.close()
    
        
        
        
        
        
        
    
    
    


# In[43]:


print(len(unique_prod_links))

