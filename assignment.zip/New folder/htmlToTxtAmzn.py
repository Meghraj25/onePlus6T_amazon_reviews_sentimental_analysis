
# coding: utf-8

# In[4]:


import mysql.connector
import requests
from bs4 import BeautifulSoup
from datetime import datetime
import os
import confi
import mysql.connector
import zlib, base64


# In[2]:


import random
import time
import pickle


# In[5]:


connect = confi.dbConnect()
mycursor = connect.cursor()


# In[6]:


date_time = datetime.now().strftime("%m_%d_%Y") #Todays date with 'm_d_y' format

detailspath = "corpus/us/amazon/details/" # PATH FOR STORING DETAILS P
path = "corpus/us/amazon/"+date_time

mycursor.execute("SELECT DISTINCT category_name FROM us_amazon_input WHERE status = 1")
categories = [list(i)[0] for i in mycursor.fetchall()]

if not os.path.isdir("corpus/us/amazon/"+date_time): #Checks If directory with todays date exists or not
    os.mkdir(path)
    for category in categories:
        os.mkdir(path+"/"+category)
        
for category in categories:
    if not os.path.isdir("corpus/us/amazon/details/"+category):
        os.mkdir("corpus/us/amazon/details/"+category)    


# In[7]:


# ALL INPUT URLS FROM DATABASE
mycursor.execute("SELECT * FROM us_amazon_input WHERE status = 1")
inputs = mycursor.fetchall()


# In[8]:


with open('user_agent_list.pickle', 'rb') as handle:
    user_agent_list = pickle.load(handle)
    
with open('proxies.pickle', 'rb') as handle:
    proxies = pickle.load(handle)


# In[14]:


def pageCrawler(link,category,catid,pg):
    
    def blockCheck(myLink): # CATCH CAPTCHA PAGES AND RETURN ONLY TRUE RESPONSE
        
        try:
            sourceCode = requests.get(link,headers = {'User-Agent':random.choice(user_agent_list)},proxies=proxies)
        except:
            print('Sleeping for 5 seconds')
            time.sleep(5)
            blockCheck(myLink)
            
        plaintext = sourceCode.text
        soup = BeautifulSoup(plaintext)
        # CHECK IF RESPONSE TITLE IS ROBOT CHECK (CAPTCHA PAGE): IF NOT IT RECALLS SAME FUNCTION OR IT RETURNS HTML RESPONSE       
        if soup.find('title') is None:
            return plaintext,soup
        elif soup.find('title').text == 'Robot Check':
            return blockCheck(myLink)
        else:
            return plaintext,soup
    
    
    text,soups = blockCheck(link)

    text = text+'<url>'+link+'</url>'
    code = base64. b64encode(zlib. compress(text. encode('utf-8'),9))
    code = code. decode('utf-8')

    text_file = open(path+'/'+category+'/MSFT_US_Amazon_cat_'+catid+'_pg_'+str(pg)+'_'+category+".zlib", "w" ,encoding="utf-8")
    text_file.write(code)
    text_file.close()
    
    
    # ITERATE THROUGH ALL PRODUCTS ON THE CATEGORY PAGE WITH DIV TAGS
    for product in soups.find_all('div',{'class':'s-result-item'}): 
        SKU = product['data-asin']
        # CHECKS IF DETAILS PAGE IS ALREADY SAVED OR NOT
        if SKU not in SKUs: 
            prodUrlTag = product.find('a',{'class':'a-link-normal a-text-normal'})
            prodUrl = '-'
            if prodUrlTag is not None:
                prodUrl = prodUrlTag['href']
            detailLinks.append([SKU,'https://www.amazon.com'+prodUrl,category])
            
            
    # HANDLES PAGINATION
    if soups.find('ul',{'class':'a-pagination'}) is not None:
        nextPage = soups.find('ul',{'class':'a-pagination'}).find('li',{'class':'a-last'}).find('a')
        # IF NEXT PAGE BUTTON HAS URL IT CALLS SAME FUNCTION AGAIN WITH NEW URL
        if nextPage is not None:
            pg += 1
            return pageCrawler('https://www.amazon.com'+nextPage['href'],category,catid,pg)
        
    
              


# In[15]:


#ALL DETAIL PAGE LINKS
detailLinks = []
for inp in inputs:
    
    # LIST OF ALL SKU OF SPECIFIC CATEGORY
    filesList=os.listdir('corpus/us/amazon/details/'+inp[1]+'/') 
    SKUs=[(x.split('.')[0]).split('-')[-1] for x in filesList]
    pageCrawler(inp[5],inp[1],str(inp[0]),1)
    

with open(path+'/'+date_time+'amazon_detailLinks.pkl', 'wb') as f:
    pickle.dump(detailLinks, f)


# In[39]:


def detailsCrawler(detailLink,sku,category):
    
        try:
            sourceCode = requests.get(detailLink,headers = {'User-Agent':random.choice(user_agent_list)},proxies=proxies)
        except:
            print('sleeping for 5 seconds')
            time.sleep(5)
            detailsCrawler(detailLink,sku,category)
            
        plaintext = sourceCode.text
        soup = BeautifulSoup(plaintext)
        
        # CHECK IF RESPONSE TITLE IS ROBOT CHECK (CAPTCHA PAGE): IF NOT IT RECALLS SAME FUNCTION OR IT RETURNS HTML RESPONSE       
        if soup.find('title').text == 'Robot Check': 
            return detailsCrawler(detailLink,sku,category)
        else:
            text = plaintext+'<url>'+detailLink+'</url>'
            code = base64. b64encode(zlib. compress(text. encode('utf-8'),9))
            code = code. decode('utf-8')

            text_file = open(detailspath+category+'/'+'MSFT-US-Amazon-Prod-'+sku+".zlib", "w" ,encoding="utf-8")
            text_file.write(code)
            text_file.close()
            
    
        
        
    


# In[2]:


for detailLink in detailLinks:
    
    detailsCrawler(detailLink[1],detailLink[0],detailLink[2]) 

