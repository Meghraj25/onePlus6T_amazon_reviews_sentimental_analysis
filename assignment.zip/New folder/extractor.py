
# coding: utf-8

# In[1]:


import os
from bs4 import BeautifulSoup 
import re
import zlib, base64
import ast


# In[5]:


path = 'corpus/us/dell/06_28_2019/details/'
folder = os.fsencode(path)


# In[15]:



mains = []
c = 0
for file in os.listdir(folder):
    entry = {}
    
    filename = os.fsdecode(file)
    sku = re.sub(r'\.zlib$', '', filename) #GET SKU CODE FROM FILE NAME
    
    
    with open(path+filename, "rb") as myfile:
        rencode = myfile.read()
        
    rdencode = zlib.decompress(base64.b64decode(rencode)) #DECODE ZLIB FILE TO PLAIN TEXT
    
    
    soup = BeautifulSoup(rdencode,'html.parser') 
    
    
    entry['Makers_id'] = 'NULL' #MAKERS ID
    entry['Category_id'] = 1 #CATEGORY ID
    entry['Super_Category'] = '' #SUPER CATEGORY
    entry['Country'] = 'US' #COUNTRY
    entry['Retailer'] = 'Dell' #RETAILER
    entry['Brand'] = 'Dell' #BRAND
    entry['Media_type'] = 'Website' #MEDIA TYPE
    entry['Market'] = 'Internet' #MARKET
    
    #PRODUCT URL
    entry['product_url'] = ''
    prd_url = soup.find('url')
    if prd_url is not None:
        entry['product_url'] = prd_url.text.strip()
    
    #ADDITIONAL OFFER 1
    entry['Additional_offers_1'] = ''
    add_offer1 = soup.find('a',{'cf-title':'Special Offers'})
    if add_offer1 is not None:
        x = ast.literal_eval(add_offer1['cf-message']) #STRING TO DICTIONARY
        entry['Additional_offers_1'] = x[0]['shortDescription'].strip()

        
    
    #ADDITIONAL OFFER 2
    entry['Additional_offers_2'] = ''
    add_offer2 = soup.find('span',{'class':'dpaPrice'})
    if add_offer2 is not None:
        entry['Additional_offers_2'] = 'As Low as '+ add_offer2.text.strip() + '/mo.'
        
    #MODEL NAME
    entry['Model_name'] = ''
    model_name = soup.find('h1',{'class':'cf-pg-title'})
    if model_name is not None:
        entry['Model_name'] = model_name.find('span').text.strip()
    model_name =  soup.find('div',{'class':'product-title'})   
    if model_name is not None:
        entry['Model_name'] = model_name.find('h1').text.strip()
    
           
    #SKU
    entry['SKU'] = sku   
        
    #PRODUCT DESCRIPTION
    entry['Product_description'] = ''
    product_desc = soup.find_all('div',{'class':'tech-spec-content'})
    if product_desc is not None:
        for pd in product_desc:
             entry['Product_description'] += pd.text.strip()         
    product_desc = soup.find_all('div',{'class':'cf-read-only-wrap'})
    if product_desc is not None:
        for pd in product_desc: 

            entry['Product_description'] += pd.find('div').text.strip()
            
            
    #REGULAR PRICE
    entry['Regular_price'] = ''
    reg_price = soup.find('span',{'class':'market-value text-strikethru'})
    if reg_price is not None:
        entry['Regular_price'] = reg_price.text.strip()
    reg_price = soup.find('div',{'class':'strikethrough cf-price'})
    if reg_price is not None:
        entry['Regular_price'] = reg_price.text.strip()    
        
        
    #SALE PRICE & UNIT PRICE
    entry['Sale_price'] = ''
    entry['Unit_price'] = ''
    sale_price = soup.find('span',{'class':'price'})
    if sale_price is not None:
        entry['Sale_price'] = sale_price.text.strip()  
        entry['Unit_price'] = sale_price.text.strip() 
    sale_price = soup.find('div',{'class':'cf-rr-total'})
    if sale_price is not None:
        entry['Sale_price'] = sale_price.find('div',{'class':'cf-price'}).text.strip()  
        entry['Unit_price'] = sale_price.find('div',{'class':'cf-price'}).text.strip()
    
    
    #DOLLAR OFF
    entry['Dolar_off'] = ''
    dolar_price = soup.find('div',{'class':'cf-blue-text'})
    if dolar_price is not None:
        entry['Dolar_off'] = dolar_price.text.strip()  
        
    dolar_price = soup.find('div',{'class':'cf-price'})
    if dolar_price is not None:
        entry['Dolar_off'] = dolar_price.text.strip()  
        
    dolar_price = soup.find('span',{'class':'total-savings'})
    if dolar_price is not None:
        entry['Dolar_off'] = dolar_price.text.strip()
        
    mains.append(entry)   

    c += 1
    if c == 100:
        break
   


# In[ ]:


print()


# In[16]:


import pandas as pd
df = pd.DataFrame(mains)


# In[17]:


df.to_csv('Dell_us3.csv')

