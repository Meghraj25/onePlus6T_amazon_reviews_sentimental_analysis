
# coding: utf-8

# In[21]:


import mysql.connector
import requests
from bs4 import BeautifulSoup
from datetime import datetime
import os
import confi
import mysql.connector
import zlib, base64


# In[22]:


import random
import time
import pickle
import json


# In[23]:


user_agent_list = ['Mozilla/5.0 (X11; U; UNICOS lcLinux; en-US) Gecko/20140730 (KHTML, like Gecko, Safari/419.3) Arora/0.8.0','Mozilla/5.0 (X11; U; Linux; de-DE) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0','Mozilla/5.0 (Windows; U; ; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0','Mozilla/5.0 (Windows; U; ; en-NZ) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0','Mozilla/5.0 (Windows; U; ; en-EN) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.8.0']
proxies = {1: {'https': '178.128.75.148:3128'}}


# In[24]:


connect = confi.dbConnect()
mycursor = connect.cursor()


# In[25]:


date_time = datetime.now().strftime("%m_%d_%Y") #Todays date with 'm_d_y' format

detailspath = "corpus/us/lenovo/details/" # PATH FOR STORING DETAILS P
path = "corpus/us/lenovo/"+date_time

mycursor.execute("SELECT DISTINCT category_name FROM us_lenovo_input WHERE status = 1")
categories = [list(i)[0] for i in mycursor.fetchall()]

if not os.path.isdir("corpus/us/lenovo/"+date_time): #Checks If directory with todays date exists or not
    os.mkdir(path)
    for category in categories:
        os.mkdir(path+"/"+category)
        
for category in categories:
    if not os.path.isdir("corpus/us/lenovo/details/"+category):
        os.mkdir("corpus/us/lenovo/details/"+category)    


# In[26]:



mycursor.execute("SELECT * FROM us_lenovo_input WHERE status = 1")
inputs = mycursor.fetchall()


# In[27]:


def pageCrawler(link,category,catid):
    sourceCode = requests.get(inp[5],headers = {'User-Agent':random.choice(user_agent_list)},proxies=proxies)
    plaintext = sourceCode.text
    soup = BeautifulSoup(plaintext)

    text = plaintext+'<url>'+link+'</url>'
    code = base64. b64encode(zlib. compress(text. encode('utf-8'),9))
    code = code. decode('utf-8')

    text_file = open(path+'/'+category+'/MSFT_US_lenovo_cat_'+catid+category+".zlib", "w" ,encoding="utf-8")
    text_file.write(code)
    text_file.close()

    products = soup.find_all('div',{'class':'product'})
    if len(products) == 0:
        products = soup.find_all('li',{'class':'product-column'})
    if len(products) == 0:
        products = soup.find_all('li',{'id':'product-'})


    for product in products:
        product_button = product.find('div',{'class':'title'})
        product_button1 = product.find('a')
        if product_button is not None:
            product_href = product_button.find('a')['href']

        elif product_button1 is not None:
            product_href = product_button1['href']

        SKU = product_href.split('/')[-1]
        if SKU not in SKUs:
            detailLinks.append([SKU,'https://www.lenovo.com'+product_href,category])
        


# In[28]:


detailLinks = []
for inp in inputs:
    filesList=os.listdir('corpus/us/lenovo/details/'+inp[1]+'/') 
    SKUs=[(x.split('.')[0]).split('-')[-1] for x in filesList]
    pageCrawler(inp[5],inp[1],str(inp[0]))


# In[30]:


def detailsCrawler(detailLink,sku,category):
    
        try:
            sourceCode = requests.get(detailLink,headers = {'User-Agent':random.choice(user_agent_list)},proxies=proxies)
        except:
            print('sleeping for 5 seconds')
            time.sleep(5)
            detailsCrawler(detailLink,sku,category)
            
        plaintext = sourceCode.text
        soup = BeautifulSoup(plaintext)
        
        # CHECK IF RESPONSE TITLE IS ROBOT CHECK (CAPTCHA PAGE): IF NOT IT RECALLS SAME FUNCTION OR IT RETURNS HTML RESPONSE       
        text = plaintext+'<url>'+detailLink+'</url>'
        code = base64. b64encode(zlib. compress(text. encode('utf-8'),9))
        code = code. decode('utf-8')

        text_file = open(detailspath+category+'/'+'MSFT-US-lenovo-Prod-'+sku+".zlib", "w" ,encoding="utf-8")
        text_file.write(code)
        text_file.close()


# In[31]:


for detailLink in detailLinks:
    
    detailsCrawler(detailLink[1],detailLink[0],detailLink[2]) 

